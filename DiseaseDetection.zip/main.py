import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

data = pd.read_csv('DiseaseAndSymptoms.csv')

df = pd.DataFrame(data)
data.fillna('None', inplace=True)

symptom_columns = [col for col in data.columns if 'Symptom' in col]
for column in symptom_columns:
    le = LabelEncoder()
    data[column] = le.fit_transform(data[column])

# Features (symptoms) and target (disease)
X = data[symptom_columns].values
y = data['Disease'].values

# Encode the target labels (diseases)
le_disease = LabelEncoder()
y_encoded = le_disease.fit_transform(y)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42)

# Build the Random Forest classifier model
model = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f"Test Accuracy: {accuracy * 100:.2f}%")


def predict_disease():
    print("Enter symptoms (comma-separated) from the following list:")
    print("1. itching")
    print("2. skin_rash")
    print("3. nodal_skin_eruptions")
    print("4. None (if symptom is absent)")

    # Collect user input for symptoms
    user_symptoms = []
    for i in range(len(symptom_columns)):
        symptom = input(f"Enter Symptom {i+1}: ").strip().lower()
        user_symptoms.append(symptom)

    # Encode the symptoms input by the user
    encoded_symptoms = []
    for i, symptom in enumerate(user_symptoms):
        if symptom in le.classes_:
            encoded_symptoms.append(le.transform([symptom])[0])
        else:
            # If the symptom is not in the list, assume it's None
            encoded_symptoms.append(le.transform(['None'])[0])

    # Pad with 'None' if less than 17 symptoms were provided
    while len(encoded_symptoms) < len(symptom_columns):
        encoded_symptoms.append(le.transform(['None'])[0])

    # Predict the disease based on the input symptoms
    prediction = model.predict([encoded_symptoms])
    predicted_disease = le_disease.inverse_transform(prediction)

    print(f"Predicted Disease: {predicted_disease[0]}")


# Call the function to get user input and predict disease
predict_disease()
